package menu;

import Schedule.Day;
import Schedule.Week;
import Schedule.Year;

import java.util.ArrayList;
import java.util.Scanner;

public class Appointments {
    Scanner sc = new Scanner(System.in);

//    private static ArrayList<Day> dayList = new ArrayList<>(5);
    Year weekDay = new Year();
    public Appointments() {
//        for (int i = 0; i < 5; i++) {
//            day.getWeek();
//            //dayList.add(new Day());  // DAYCHOICE HERE???
//        }
    }

    public void appointmentManage( int whichMethod) {
        switch (whichMethod) {
            case 1:
                weekDay.getWeek(weekChoice());
                //dayList.get(whichDay - 1).createAppointment(whichDay);
                break;
            case 2:
                //Edit
                break;
            case 3:
                //Delete
                break;
            default:
                System.out.println("Something went wrong in appointmentManageMethod");
                break;
        }
    }

    public void viewSchedule() {
        System.out.println(weekDay.getWeek(weekChoice()));

//        for (int i = 0; i < 5; i++) {
//            System.out.println("Day " + (i + 1));
//            System.out.println(W.get(i).getAppointmentOnThisDay());
//            // System.out.println(dayList.get(i).getAppointmentOnThisDay());
//            System.out.println();
//        }
    }

//    public void viewScheduleForOneDay(int whichDay) {
//        System.out.println(dayList.get(whichDay - 1).getAppointmentOnThisDay());
//    }

    public void createAppointment() {
        //modtag dag?
        String newTime = sc.nextLine();
        switch (newTime) {
            case "10:00":
                //
                break;
            case "10:30":
                //erstat empty med customer name
            case "11:00":
                //erstat empty med customer name
                break;
            case "11:30":
                //erstat empty med customer name
                break;
            case "12:00":
                //erstat empty med customer name
                break;
            case "12:30":
                //erstat empty med customer name
                break;
            case "13:00":
                //erstat empty med customer name
                break;
            case "13:30":
                //erstat empty med customer name
                break;
            case "14:00":
                //erstat empty med customer name
                break;
            case "14:30":
                //erstat empty med customer name
                break;
            case "15:00":
                //erstat empty med customer name
                break;
            case "15:30":
                //erstat empty med customer name
                break;
            case "16:00":
                //erstat empty med customer name
                break;
            case "16:30":
                //erstat empty med customer name
                break;
            case "17:00":
                //erstat empty med customer name
                break;
            case "17:30":
                //erstat empty med customer name
                break;
            default:
                System.out.println("Something went wrong in the switch");
        }
    }

    public String readName() {
        System.out.println("Enter name of customer: ");
        String name = sc.nextLine();
        return name;
    }
    public int weekChoice(){
        System.out.print("write the week number: ");
        int weekChoice = sc.nextInt();
        return weekChoice;
    }
}
