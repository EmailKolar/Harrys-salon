package Schedule;

import menu.Appointments;
import java.util.ArrayList;
import java.util.Scanner;

public class Day {

    Scanner sc = new Scanner(System.in);
    private ArrayList<String> appointmentOnThisDay = new ArrayList<>();

    public void createAppointment(int whichDay) {
        printScheduleIfMultipleAppointments(whichDay);
        System.out.print("Write the timeslot: ");
        String timeslot = sc.nextLine();
        appointmentOnThisDay.add(timeslot);
    }

    public ArrayList getAppointmentOnThisDay(){
        return appointmentOnThisDay;
    }

    private void printScheduleIfMultipleAppointments(int whichDay){
        if (appointmentOnThisDay.size() >= 1) {
            System.out.println("The Schedule for day " + whichDay + " looks like this ");
            new Appointments().viewScheduleForOneDay(whichDay);
        }

    }
}

