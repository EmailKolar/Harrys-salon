package Schedule;

import java.util.ArrayList;

public class Week {

    private ArrayList<Day> week = new ArrayList<>();

    private void createWeek() {
        for (int i = 0; i < 5; i++) {
            week.add(new Day());
        }
    }

    public Week() {
        createWeek();
    }

    public ArrayList<Day> getWeek() {
        return week;
    }

    @Override
    public String toString() {
        return "Week{" +
                "week=" + week +
                '}';
    }
}
