package Schedule;

import menu.Appointments;
import java.util.ArrayList;
import java.util.Scanner;

public class Day {

    Scanner sc = new Scanner(System.in);
    private ArrayList<String> appointmentOnThisDay = new ArrayList<>();



    public Day(){
        generateTimeslots();
    }

//    public void createAppointment(int whichDay) {
//        printScheduleIfMultipleAppointments(whichDay);
//        System.out.print("Write the timeslot: ");
//        String timeslot = sc.nextLine();
//        appointmentOnThisDay.add(timeslot);
//    }

    public ArrayList<String> getAppointmentOnThisDay(){
        return appointmentOnThisDay;
    }

//    private void printScheduleIfMultipleAppointments(int whichDay){
//        if (appointmentOnThisDay.size() >= 1) {
//            System.out.println("The Schedule for day " + whichDay + " looks like this ");
//            new Appointments().viewScheduleForOneDay(whichDay);
//        }
//    }
    public void generateTimeslots(){
        appointmentOnThisDay.add("10:00, empty");
        appointmentOnThisDay.add("10:30, empty");
        appointmentOnThisDay.add("11:00, empty");
        appointmentOnThisDay.add("11:30, empty");
        appointmentOnThisDay.add("12:00, empty");
        appointmentOnThisDay.add("12:30, empty");
        appointmentOnThisDay.add("13:00, empty");
        appointmentOnThisDay.add("13:30, empty");
        appointmentOnThisDay.add("14:00, empty");
        appointmentOnThisDay.add("14:30, empty");
        appointmentOnThisDay.add("15:00, empty");
        appointmentOnThisDay.add("15:30, empty");
        appointmentOnThisDay.add("16:00, empty");
        appointmentOnThisDay.add("16:30, empty");
        appointmentOnThisDay.add("17:00, empty");
        appointmentOnThisDay.add("17:30, empty");
    }

    @Override
    public String toString() {
        return "Day{" +
                "appointmentOnThisDay=" + appointmentOnThisDay +
                '}';
    }
}

