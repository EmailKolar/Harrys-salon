package menu;

import java.util.Scanner;

public class Payment {
    Scanner sc = new Scanner(System.in);



    public double registerPayment() {
        System.out.println("Enter amount payed by customer: ");
        double paymentAmount = sc.nextInt();
        //String missingPayment = "Payment is " + paymentAmount;
        return paymentAmount;
    }

    Appointments a = new Appointments();
    public void updatePayment() {
        int week = a.weekChoice();
        int day = a.dayChoice();
        //a.viewSingleDaySchedule(week, day);
        a.viewDayAppointments(week, day);
        String timeslot = a.readTimeslot();
        String name = timeslot + "-" + a.readName() + " Amount payed: " + registerPayment(); //TODO: Don't ask for name
        a.year.getWeek(week).getDay(day).addAppointment(a.timeslotToIndex(timeslot), name);
    }
}
