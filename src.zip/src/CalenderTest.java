import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalenderTest {


//        Date today = Calendar.getInstance().getTime();
//        System.out.println();
//
//
//        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM");
//        Date date = new Date();
//        System.out.println(formatter.format(date));
//        System.out.println(date);
//
//        Calendar c = Calendar.getInstance();
//        //c.setTime(yourDate);
//        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
//        new SimpleDateFormat("EE").format(dayOfWeek);
}
