package menu;

import Schedule.Day;
import java.util.ArrayList;

public class Appointments {

    private static ArrayList <Day> dayList = new ArrayList<>(5);

    public Appointments(){
        for (int i = 0; i < 5; i++) {
            dayList.add(new Day());
        }
    }

    public void appointmentManage(int whichDay, int whichMethod){
        switch (whichMethod){
            case 1:
                dayList.get(whichDay-1).createAppointment(whichDay);
                break;
            case 2:
                //Edit
                break;
            case 3:
                //Delete
                break;
            default:
                System.out.println("Something went wrong in appointmentManageMethod");
                break;

        }

    }
    public void viewSchedule(){
        for (int i = 0; i < 5; i++) {
            System.out.println("Day " + (i + 1));
            System.out.println(dayList.get(i).getAppointmentOnThisDay());
            System.out.println();
        }
    }

    public void viewScheduleForOneDay(int whichDay){
        System.out.println(dayList.get(whichDay-1).getAppointmentOnThisDay());
    }
}
