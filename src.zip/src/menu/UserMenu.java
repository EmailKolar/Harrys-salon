package menu;

import Schedule.Day;

import java.util.ArrayList;
import java.util.Scanner;

public class UserMenu {
    Scanner sc = new Scanner(System.in);

    public void barberMenu() {
        ArrayList<String> barberMenulist = new ArrayList<>();
        barberMenulist.add("Create Appointment");
        barberMenulist.add("Edit Appointment");
        barberMenulist.add("Delete Appointment");
        barberMenulist.add("View Schedule");
        barberMenulist.add("Register Vacation");
        Menu barberMenu = new Menu("What do you want to do", "Type the number", barberMenulist);

        Appointments appointments = new Appointments();

        do {
            barberMenu.printMenu();
            switch (barberMenu.readChoice()) {
                case 1:
                    //System.out.println("You chose: " + barberMenulist.get(0));
                    appointments.appointmentManage(dayChoice(), 1);
                    break;
                case 2:
                    System.out.println("You chose: " + barberMenulist.get(1));
                    //TODO Edit Appointment
                    break;
                case 3:
                    System.out.println("You chose: " + barberMenulist.get(2));
                    //TODO Delete Appointment
                    break;
                case 4:
                    appointments.viewSchedule();
                    break;
                case 5:
                    System.out.println("You chose: " + barberMenulist.get(4));
                    //TODO Register Vacation
                    break;
                default:
                    System.out.println("Your choice is out of bounds...\n");
                    break;
            }
        } while (isDone() == false);
    }

    public void accountantMenu() {
        //System.out.println("you chose accountant menu");
        System.out.println("Write a date to look at the appointments, for that day");
    }

    public int dayChoice() {
        int dayChoice = 0;
        System.out.println("What day do you want to edit in: today(1) second day(2)" +
                " third day(3) fourth day (4) fifth day(5)");
        try {
            dayChoice = sc.nextInt();
            if (dayChoice > 5 || dayChoice < 1)
                dayChoice();
        } catch (Exception e) {
            dayChoice();
        }

        return dayChoice;
    }

    public boolean isDone() {
        Scanner sc = new Scanner(System.in);
        boolean isDone = false;
        System.out.println("Are you done with the program? no(1) yes(2) ");
        int x = sc.nextInt();

        switch (x) {
            case 1:
                break;
            case 2:
                System.out.println("Okay. bye!");
                isDone = true;
                break;
            default:
                System.out.println("Wrong input. go again");
                isDone();
                break;
        }
        return isDone;
    }
}
