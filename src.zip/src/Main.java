import menu.Appointments;
import menu.MenuRun;
import password.Password;


public class Main {
    public static void main(String[] args) {
//        Calendar c = Calendar.getInstance();
//        System.out.println("The Current Date is:" + c.getTime());

        new Password().checkPassword();
        new MenuRun().run();



    }
}
