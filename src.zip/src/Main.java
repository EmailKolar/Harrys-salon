import menu.Appointments;
import menu.MenuRun;
import password.Password;

import java.util.ArrayList;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        //new Password().checkPassword();
        new MenuRun().run();



        //System.out.println(timeslot.get(0).substring(timeslot.get(0).lastIndexOf(" ") + 1));

        //print timeslot if timeslot is empty
//        for (int i = 0; i < timeslot.size(); i++) {
//            if (timeslot.get(i).substring(timeslot.get(i).lastIndexOf(" ")).equals(" empty")) {
//                System.out.println(timeslot.get(i));
//            }
//        }

        //book timeslot
        Scanner sc = new Scanner(System.in);
        String newTime = sc.nextLine();
        switch (newTime) {
            case "11:00":
                //erstat empty med customer name
                break;
            }
    }
}
